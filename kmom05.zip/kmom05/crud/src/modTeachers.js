module.exports = {
    teacherAsTable: teacherAsTable
};

function teacherAsTable(res) {
    let str;

    //Got the error message "Line x exceeds the maximum line length of 100  max-len"
    //so I had to destroy the look of the following code for the tables to make it work
    str = "+-----------+---------------------+------------+--------+";
    str += "----------+-------+------------+--------+\n";
    str += "| Akronym   | Namn                | Avdelning  |";
    str += " Kön    | Lön      | Komp  |  Född      | Ålder  |\n";
    str += "|-----------|---------------------|------------|--------";
    str += "|----------|-------|------------|--------|\n";
    for (const row of res) {
        let fodd = new Date(row.fodd).toISOString().slice(0, 10);

        str += "| ";
        str += row.akronym.padEnd(10);
        str += "| ";
        str += (row.fornamn + " " + row.efternamn).padEnd(20);
        str += "| ";
        str += row.avdelning.padEnd(11);
        str += "| ";
        str += row.kon.padStart(6);
        str += " | ";
        str += row.lon.toString().padStart(8);
        str += " | ";
        str += row.kompetens.toString().padStart(5);
        str += " | ";
        str += fodd.padEnd(8);
        str += " | ";
        str += row.alder.toString().padStart(6);
        str += " |\n";
    }
    str += "+-----------+---------------------+------------+";
    str += "--------+----------+-------+------------+--------+\n";

    return str;
}
