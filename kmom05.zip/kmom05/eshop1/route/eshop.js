/**
 * Route for bank.
 */
"use strict";

const express    = require("express");
const router     = express.Router();


//Body Parser aktiveras bara i den fil vi använder den,
//alltså i samma fil som vår post-route ligger
const bodyParser = require("body-parser");

//Middleware som kan läggas till i vår route 
//för att parsa innehåller i postade formulär
const urlencodedParser = bodyParser.urlencoded({ extended: false });
const eshop       = require("../src/eshop.js");
const sitename   = "| Eshop";

module.exports = router;

router.get("/index", (req, res) => {
    let data = {
        title: `Welcome ${sitename}`
    };

    res.render("eshop/index", data);
});

router.get("/category", async (req, res) => {
    let data = {
        title: `Category ${sitename}`
    };

   // data.res = await eshop.showBalance();
    data.res = await eshop.showCategory();

    res.render("eshop/category", data);
});

router.get("/product/:id", async (req, res) => {
    let data = {
        title: `Product ${sitename}`
    };

    // data.res = await eshop.showBalance();
    data.res = await eshop.productId(req.params.id);

    res.render("eshop/product", data);
});

router.get("/create", (req, res) => {
    let data = {
        title: `Create ${sitename}`
    };

    res.render("eshop/create", data);
});

router.post("/create", urlencodedParser, async (req, res) => {
    //Extract the data from the posted form
    //console.log(JSON.stringify(req.body, null, 4));
    
    //Send data to a stored procedure
    //I routens callback har vi nu det postade formuläret, re.body.x)
    await eshop.createProduct(req.body.produktkod, req.body.produktnamn, req.body.beskrivning, req.body.kategori, req.body.pris);
    
    //Vi redirectas/skickas vidare till routen /bank/balance som renderar ett svar
    
    //res.redirect("/eshop/balance");
    res.redirect("/eshop/product");
    //Nu måste vi extrahera datat som kommer i det postade formnuläret
    //Vi använder modulen body-parser
    //Den extraherar den kodade infon i HTTP-requesten
});

//Dynamisk route som tar en parameter så routen blev bank/acoount/:id
//där :id representerar kontots id 
//Exempelvis: bank/account/2222 ger Evas konto
router.get("/account/:id", async (req, res) => {
    //hur representationen av :id kan hämtas i datan om requesten via req.params.id
    //Som att skicka en parameter via länken

    let id = req.params.idz;
    let data = {
        title: `Product ${id} ${sitename}`,
        account: id
    };

    //Anropar en lagrad procedur som hämtar detaljer
    //om just ett konto id, som bifogas som ett argument till funktionen
//    data.res = await eshop.showAccount(id);
    data.res = await eshop.productId(id);
    res.render("eshop/account-view", data);
});

//samma som acconut/id enda skillnaden är vy och title
router.get("/edit/:id", async (req, res) => {
    let id = req.params.id;
    let data = {
        title: `Edit account ${id} ${sitename}`,
        account: id
    };

    data.res = await eshop.productId(id);

    res.render("eshop/account-edit", data);
});

router.post("/edit", urlencodedParser, async (req, res) => {
    //console.log(JSON.stringify(req.body, null, 4));
    await eshop.editProduct(req.body.produktkod, req.body.produktnamn, req.body.pris);
    res.redirect(`/eshop/edit/${req.body.produktkod}`);
});

router.get("/delete/:id", async (req, res) => {
    let id = req.params.id;
    let data = {
        title: `Delete account ${id} ${sitename}`,
        account: id
    };

    data.res = await eshop.productId(id);

    res.render("eshop/account-delete", data);
});

router.post("/delete", urlencodedParser, async (req, res) => {
    //console.log(JSON.stringify(req.body, null, 4));
    await eshop.deleteProduct(req.body.produktkod);
    res.redirect(`/eshop/product`);
});

router.get('/',function(req,res){
    res.render('search.html');
    });
    
    router.get('/search',function(req,res){
    connection.query('SELECT first_name from TABLE_NAME where first_name like "%'+req.query.key+'%"',
    function(err, rows, fields) {
    if (err) throw err;
    var data=[];
    for(i=0;i<rows.length;i++)
    {
    data.push(rows[i].first_name);
    }
    res.end(JSON.stringify(data));
    });
    });
