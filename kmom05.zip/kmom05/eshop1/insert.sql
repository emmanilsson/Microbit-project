-- Skapa databas
-- CREATE DATABASE skolan;
CREATE DATABASE IF NOT EXISTS projekt;

-- Välj vilken databas du vill använda
USE projekt;

-- -- Radera en databas med allt innehåll
-- DROP DATABASE skolan;
-- 
-- -- Visa vilka databaser som finns
-- SHOW DATABASES;

-- Visa vilka databaser som finns
-- som heter något i stil med *skolan*
SHOW DATABASES LIKE "%projekt%";

-- Skapa en användare user med lösenorder pass och ge tillgång oavsett
-- hostnamn. 

CREATE USER IF NOT EXISTS 'user'@'%'
IDENTIFIED
WITH mysql_native_password -- MySQL with version > 8.0.4
BY 'pass'
;

-- -- Skapa användaren med en bakåtkompatibel lösenordsalgoritm.
-- CREATE USER IF NOT EXISTS 'user'@'%'
--     IDENTIFIED WITH mysql_native_password
--     BY 'pass'
-- ;

-- -- Ta bort en användare
-- DROP USER 'user'@'%';
-- DROP USER IF EXISTS 'user'@'%';

-- Ge användaren alla rättigheter på en specifk databas.
GRANT ALL PRIVILEGES
    ON projekt.*
    TO 'user'@'%'
;

-- -- Skapa användaren "user" med
-- -- lösenordet "pass" och ge
-- -- fulla rättigheter till databasen "skolan"
-- -- när användaren loggar in från maskinen "localhost"
-- GRANT ALL ON skolan.* TO user@localhost IDENTIFIED BY 'pass';

-- Visa vad en användare kan göra mot vilken databas.
SHOW GRANTS FOR 'user'@'%';

-- -- Visa för nuvarande användare
SHOW GRANTS FOR CURRENT_USER;

DROP TABLE IF EXISTS microbits;

CREATE TABLE microbits
(
	`time` DATETIME NOT NULL DEFAULT NOW(),
	id_unit CHAR(20),
    light VARCHAR(100),
    temperature VARCHAR(100),
    x INT,
    y INT
    
   -- PRIMARY KEY (id)
);

DELETE FROM microbits;
-- Trigger, gör insert


DROP TABLE IF EXISTS sensor_data;

CREATE TABLE sensor_data
(
	time1 INT,
	extra INT,
	time2 INT,
    temp INT,
    time3 INT,
    light INT
);

DELETE FROM sensor_data;


INSERT INTO microbits (id_unit, light, temperature, x, y) VALUES (111, 23, 17, 10, 10);
INSERT INTO microbits (id_unit, light, temperature, x, y) VALUES (222, 12, 43, 14, 9);
SELECT * FROM microbits ORDER BY id_unit ;
SELECT * FROM sensor_data;




DROP PROCEDURE IF EXISTS show_history;
DELIMITER ;;
CREATE PROCEDURE show_history()
BEGIN
    SELECT `time`, id_unit, temperature, light FROM microbits;
END
;;
DELIMITER ;

CALL show_history();



DROP PROCEDURE IF EXISTS showId;
DELIMITER //
CREATE PROCEDURE showId(
	aId CHAR(4)
)
BEGIN
    SELECT * FROM microbits WHERE id_unit = aId;
END
//
DELIMITER ;

 CALL showId("111");