DROP VIEW IF EXISTS v_produktvy;
CREATE VIEW v_produktvy
AS
SELECT DISTINCT 
	p.produktkod AS produktkod,
	t.produktnamn AS produktnamn,
    p.kategori AS kategori,
    GROUP_CONCAT(t.typ),
    t.antal AS antal,
    p.pris AS pris
FROM v_typ AS t
    JOIN produkt AS p
        ON t.typ = p.kategori
        GROUP BY p.produktkod
;

SELECT * FROM v_produktvy;