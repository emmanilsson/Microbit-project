USE eshop;

SELECT * FROM produkt;
SELECT * FROM produkt2kategori;
SELECT * FROM kund;
SELECT * FROM kundorder;
SELECT * FROM kategori;
SELECT * FROM lagerhylla;

SELECT * FROM v_produkt;
SELECT * FROM v_typ;
SELECT * FROM v_produktvy;
SELECT * FROM eshop_log;