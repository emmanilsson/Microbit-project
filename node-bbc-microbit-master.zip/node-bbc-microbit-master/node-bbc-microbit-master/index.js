module.exports = require('./lib/bbc-microbit');
