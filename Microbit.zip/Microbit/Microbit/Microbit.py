import mysql.connector
import MySQLdb
import serial


ser = serial.Serial()
ser.baudrate = 115200
ser.port = "COM3"
ser.open()



while True:

    data = str(ser.readline())
    data2 = data[2:]
   
    data2 = data2.replace("[", "")
    data2 = data2.replace("]", "")
    data2 = data2.replace("\\r", "")
    data2 = data2.replace("\\n", "")
    data2 = data2.replace("'", "")
    data2 = data2.replace("'", "")
    data2 = data2.replace('"', "")

    print(data2)
    sensorID, temp, lightLevel = data2.split(",")

    print("SensorID: ", sensorID)
    print("Temp: ", temp)
    print("lightLevel: ", lightLevel)

    mydb = mysql.connector.connect(user='user', password='pass',
                              host='localhost',
                              database='projekt')


    mycursor = mydb.cursor()

    print(data2)
    sql = "INSERT INTO microbits (id_unit, temperature, light) VALUES ({}, {}, {})".format(sensorID, temp, lightLevel)
    val = (sensorID, temp, lightLevel)
    mycursor.execute(sql)

    mydb.commit()

    print(mycursor.rowcount, "record inserted.")
    mydb.close()