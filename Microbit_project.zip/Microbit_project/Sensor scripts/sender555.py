from microbit import *
import radio
import random
radio.on()
sensorID = 555

while True:
   display.scroll('555', wait=False, loop=True)
   sleep(10000)
   temp = str(temperature())
   lightLevel = str(display.read_light_level())
   data = [sensorID, temp, lightLevel]
   radio.send(str(data))
   print(data)
