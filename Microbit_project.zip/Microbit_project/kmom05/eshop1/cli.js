/**
 * Move 1.5 money to Eva using a command loop
 * @author Emma Nilsson
 */

"use strict";

//const move = require("./src/move.js");
const eshop = require("./src/eshop.js");

// Read from commandline
const readline = require("readline");
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Promisify rl.question to question
const util = require("util");

rl.question[util.promisify.custom] = (arg) => {
    return new Promise((resolve) => {
        rl.question(arg, resolve);
    });
};


/**
 * Main function.
 *
 * @async
 * @returns void
 */

(async function () {
    //called when ctrl + d
    // called after input and pressed [ENTER]

    const mysql = require("promise-mysql");
    const config = require("./config/db/eshop.json");

    rl.on("close", exitProgram);
    rl.on("line", handleInput);

    const db = await mysql.createConnection(config);

    rl.setPrompt("Eshop: ");
    rl.prompt();

    db.end();
})();


/**
 * Close down program and exit with a status code.
 *
 * @param {number} code Exit with this value, defaults to 0.
 *
 * @returns {void}
 */
function exitProgram(code) {
    code = code || 0;

    console.info("Exiting with status code " + code);
    process.exit(code);
    //db.end();
}


/**
 * Handle input as a command
 * @param {string} line The input from the user.
 * @returns {void}
 */
async function handleInput(line) {
    
    const mysql = require("promise-mysql");
    const config = require("./config/db/eshop.json");

    const db = await mysql.createConnection(config);
    let str;

    line = line.trim();
    let lineArray = line.split(" ");
    let cmd = lineArray[0];

    switch (cmd) {
        case "quit":
        case "exit":
            exitProgram();
            break;
        case "menu":
            console.log(
                "You can choose from the following commands:\n"
                + "exit, quit, ctrl -d + ctrl -c - to exit the program\n"
                + "help, menu - to show this menu\n"
                + "move - move 1.5 peng to Eva\n"
            );
            break;
        case "help":
            console.log(
                "You can choose from the following commands:\n"
                + "exit, quit, ctrl -d + ctrl -c - to exit the program\n"
                + "help, menu - to show this menu\n"
                + "move - move 1.5 peng to Eva\n"
            );
            break;
        case "log":
            str = await eshop.searchInventory(db, lineArray[1]);
            console.info(str);
            break; 
        case "shelf":
            str = await eshop.viewShelves(db);
            console.info(str);
            //await move.toEva(db);
            break;
        case "inventory":
            str = await eshop.searchInventory(db, lineArray[1]);
            console.info(str);
            break; 
        case "inventory":
            str = await eshop.viewInventory(db);
            console.info(str);
            break;
        case "invadd":
            str = await eshop.addToShelf(db, lineArray[1], lineArray[2], lineArray[3]);
            console.info(str);
            //await move.toEva(db);
            break;
        case "move":
            //await move.toEva(db);
            break;
        default:
            console.log("I do not know that command, enter 'menu' for a list of known commands.");
            break;
    }

    rl.prompt();
}
