USE eshop;

SET GLOBAL local_infile = 1;


DELETE FROM kategori;
DELETE FROM produkt2kategori;
DELETE FROM lagerhylla;
DELETE FROM produkt;
DELETE FROM kundorder;
DELETE FROM kund;

LOAD DATA LOCAL INFILE 'kund.csv'
INTO TABLE kund
CHARSET utf8
FIELDS
    TERMINATED BY ','
    ENCLOSED BY '"'
LINES
    TERMINATED BY '\n'
IGNORE 1 LINES
(id, fornamn, efternamn, adress, land, telefonnummer)
;

SELECT * FROM kund;



LOAD DATA LOCAL INFILE 'kundorder.csv'
INTO TABLE kundorder
CHARSET utf8
FIELDS
    TERMINATED BY ','
    ENCLOSED BY '"'
LINES
    TERMINATED BY '\n'
IGNORE 1 LINES
(ordernummer, kundID, fornamn, efternamn, adress, land, telefonnummer, antal, produkt)
;

SELECT * FROM kundorder;


LOAD DATA LOCAL INFILE 'produkt.csv'
INTO TABLE produkt
CHARSET utf8
FIELDS
    TERMINATED BY ','
    ENCLOSED BY '"'
LINES
    TERMINATED BY '\n'
IGNORE 1 LINES
(produktkod, produktnamn, beskrivning, kategori, pris)
;

SELECT * FROM produkt;



LOAD DATA LOCAL INFILE 'lagerhylla.csv'
INTO TABLE lagerhylla
CHARSET utf8
FIELDS
    TERMINATED BY ','
    ENCLOSED BY '"'
LINES
    TERMINATED BY '\n'
IGNORE 1 LINES
(produkt_namn, antal, hyllnummer)
;

SELECT * FROM lagerhylla;



LOAD DATA LOCAL INFILE 'produkt2kategori.csv'
INTO TABLE produkt2kategori
CHARSET utf8
FIELDS
    TERMINATED BY ','
    ENCLOSED BY '"'
LINES
    TERMINATED BY '\r\n'
IGNORE 1 LINES
;

SELECT * FROM produkt2kategori;

LOAD DATA LOCAL INFILE 'kategori.csv'
INTO TABLE kategori
CHARSET utf8
FIELDS
    TERMINATED BY ','
    ENCLOSED BY '"'
LINES
    TERMINATED BY '\r\n'
IGNORE 1 LINES
(typ)
;

SELECT * FROM kategori;