-- FÖRSÖKTE JOINA FEL TABELL (typ) med (produktnamn), som innehöll namn såsom Cd Skiva1, Vinylskiva1 istället för Cd skiva  
-- Går nog inte att göra i v_produkt för att de matchar, men kanske där det finns kategori för cd skiva1 har kategori Cd Skiva och Skiva ???

USE eshop;

-- log tabell
-
-- Log table
--
DROP TABLE IF EXISTS eshop_log;
CREATE TABLE eshop_log
(
    `tidsstämpel` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `händelse` VARCHAR(200),
    `produktid` INT
);

-- DELETE FROM account_log;
SELECT * FROM eshop_log;



-- cli.js


DROP PROCEDURE IF EXISTS show_log;
DELIMITER ;;
CREATE PROCEDURE show_log()
BEGIN

SELECT tidsstämpel, händelse FROM eshop_log LIMIT 5;

END
;;
DELIMITER ;



DROP VIEW IF EXISTS v_inventory;
CREATE VIEW v_inventory
AS
SELECT
    lagerhylla.produkt_namn AS produktnamn,
    lagerhylla.antal As antal,
    produkt2kat.typ As typ,
    lagerhylla.hyllnummer AS hyllnummer
FROM produkt2kategori AS produkt2kat
	JOIN lagerhylla AS lagerhylla
        ON produkt2kat.produktnamn = lagerhylla.produkt_namn
;

SELECT * FROM v_inventory;






DROP PROCEDURE IF EXISTS show_inventory;
DELIMITER ;;
CREATE PROCEDURE show_inventory()
BEGIN

SELECT produktkod, produktnamn, typ, antal FROM v_produktvy;

END
;;
DELIMITER ;


DROP PROCEDURE IF EXISTS show_shelves;
DELIMITER ;;
CREATE PROCEDURE show_shelves()
BEGIN

SELECT hyllnummer FROM lagerhylla;

END
;;
DELIMITER ;




-- index.js

DROP VIEW IF EXISTS v_produkt;
CREATE VIEW v_produkt
AS
SELECT
    lagerhylla.produkt_namn AS produktnamn,
    lagerhylla.antal As antal,
    produkt2kat.typ As typ,
    lagerhylla.hyllnummer AS hyllnummer
FROM produkt2kategori AS produkt2kat
	JOIN lagerhylla AS lagerhylla
        ON produkt2kat.produktnamn = lagerhylla.produkt_namn
;

SELECT * FROM v_produkt;



DROP VIEW IF EXISTS v_typ;
CREATE VIEW v_typ
AS
SELECT DISTINCT
	v_produkt.produktnamn AS produktnamn,
    v_produkt.antal as antal,
	kategori.typ AS typ,
    v_produkt.hyllnummer AS hyllnummer
FROM v_produkt AS v_produkt
    JOIN kategori
        ON v_produkt.typ= kategori.typ
;

SELECT * FROM v_typ;




DROP PROCEDURE IF EXISTS show_product;
DELIMITER ;;
CREATE PROCEDURE show_product()
BEGIN

DROP VIEW IF EXISTS v_produktvy;
CREATE VIEW v_produktvy
AS
SELECT DISTINCT 
	p.produktkod AS produktkod,
	t.produktnamn AS produktnamn,
    p.kategori AS kategori,
    GROUP_CONCAT(t.typ) AS typ,
    t.antal AS antal,
    p.pris AS pris,
    t.hyllnummer
FROM v_typ AS t
    JOIN produkt AS p
        ON t.typ = p.kategori
       GROUP BY p.produktkod
;

SELECT * FROM v_produktvy;

END
;;
DELIMITER ;



DROP PROCEDURE IF EXISTS create_product;
DELIMITER ;;
CREATE PROCEDURE create_product(
produktkod INT, 
produktnamn VARCHAR(100),
beskrivning VARCHAR(100),
kategori VARCHAR(100),
pris INT
)
BEGIN
INSERT INTO produkt VALUES (produktkod, produktnamn, beskrivning, kategori, pris);


DROP VIEW IF EXISTS v_produktvy;
CREATE VIEW v_produktvy
AS
SELECT DISTINCT 
	p.produktkod AS produktkod,
	t.produktnamn AS produktnamn,
    p.kategori AS kategori,
    GROUP_CONCAT(t.typ) AS typ,
    t.antal AS antal,
    p.pris AS pris,
    t.hyllnummer
FROM v_typ AS t
    JOIN produkt AS p
        ON t.typ = p.kategori
       GROUP BY p.produktkod
;

SELECT * FROM v_produktvy;

END
;;
DELIMITER ;



DROP PROCEDURE IF EXISTS show_chosenproduct;
DELIMITER ;;
CREATE PROCEDURE show_chosenproduct(
    a_produktkod INT
)
BEGIN
    SELECT * FROM produkt WHERE produktkod = a_produktkod;
END
;;
DELIMITER ;


DROP PROCEDURE IF EXISTS edit_product;
DELIMITER ;;
CREATE PROCEDURE edit_product(
    a_produktkod INT,
    a_produktnamn VARCHAR(100),
    a_pris INT
)
BEGIN
    UPDATE produkt 
		SET
        `produktnamn` = a_produktnamn,
        `pris` = a_pris
    WHERE
        `produktkod` = a_produktkod;


	-- INSERT INTO 
	-- eshop_log (crudtyp, produktid)
	-- VALUES
	-- ('Detaljer uppdaterades för ', a_produktkod);

END
;;
DELIMITER ;



--
-- Create procedure for delete product
--
DROP PROCEDURE IF EXISTS delete_product;
DELIMITER ;;
CREATE PROCEDURE delete_product(
    a_produktkod INT
)
BEGIN
    DELETE FROM produkt
    WHERE
        `produktkod` = a_produktkod;
        
	 INSERT INTO eshop_log (`händelse`, `produktid`)
	 VALUES ('Produkten raderades', produktid);
END
;;
DELIMITER ;




DROP TRIGGER IF EXISTS log_product_edit;
CREATE TRIGGER log_product_edit
AFTER UPDATE
ON produkt FOR EACH ROW
    INSERT INTO eshop_log (`händelse`, `produktid`)
        VALUES ('Detaljer uppdaterades', NEW.produktkod);



DROP TRIGGER IF EXISTS log_product_insert;
CREATE TRIGGER log_product_insert
AFTER INSERT
ON produkt FOR EACH ROW
    INSERT INTO eshop_log (`händelse`, `produktid`)
        VALUES ('Ny produkt lades till ', NEW.produktkod);





DROP VIEW IF EXISTS v_produktkatvy;
CREATE VIEW v_produktkatvy
AS
SELECT DISTINCT 
	v_produktvy.produktkod AS produktkod,
	v_produktvy.produktnamn AS produktnamn,
    v_produktvy.antal AS antal,
    v_produktvy.pris AS pris
FROM v_produktvy AS v_produktvy
    JOIN produkt2kategori AS produkt2kategori
        ON produkt2kategori.typ = vy_produkt.typ
        GROUP BY p.produktkod
;

SELECT * FROM v_produktkatvy;

















































DROP PROCEDURE IF EXISTS show_;
DELIMITER ;;
CREATE PROCEDURE show_()
BEGIN
   
   DROP VIEW IF EXISTS v_produkt;
CREATE VIEW v_produkt
AS
SELECT DISTINCT
    p.produktid AS produktid,
    l.antal As antal
FROM produkt2kategori AS p
	JOIN lagerhylla AS l
        ON p.typ = l.produkt_namn
;

SELECT * FROM v_produkt;



DROP VIEW IF EXISTS v_typ;
CREATE VIEW v_typ
AS
SELECT DISTINCT
	p.produktnamn AS produktnamn,
    p.antal as antal,
	k.typ AS typ
FROM v_produkt AS p
    LEFT JOIN kategori AS k
        ON p.typ= k.typ
;

SELECT * FROM v_typ;







DROP VIEW IF EXISTS v_produktvy;
CREATE VIEW v_produktvy
AS
SELECT DISTINCT 
	p.produktkod AS produktkod,
	t.produktnamn AS produktnamn,
    p.kategori AS kategori,
    t.antal AS antal,
    p.pris AS pris
FROM v_typ AS t
    RIGHT OUTER JOIN produkt AS p
        ON t.typ = p.kategori
;

SELECT * FROM v_produktvy;
END
;;
DELIMITER ;
