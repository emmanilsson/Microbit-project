/**
 * A module exporting functions to access the bank database.
 */
"use strict";

module.exports = {
    viewLog: viewLog,
    addToShelf: addToShelf,
    viewShelves: viewShelves,
    viewInventory: viewInventory,
    deleteProduct: deleteProduct,
    editProduct: editProduct,
    productId: productId,
    createProduct: createProduct,
    showCategory: showCategory,
    showProduct: showProduct,
    showBalance: showBalance,
    createAccount: createAccount,
    showAccount: showAccount,
    editAccount: editAccount,
    deleteAccount: deleteAccount,
    searchInventory: searchInventory
};

const mysql  = require("promise-mysql");
const config = require("../config/db/eshop.json");
let db;



/**
 * Main function.
 * @async
 * @returns void
 */
(async function() {
    db = await mysql.createConnection(config);

    process.on("exit", () => {
        db.end();
    });
})();



/**
 * Show details for an account.
 *
 * @async
 * @param {string} id A id of the account.
 *
 * @returns {RowDataPacket} Resultset from the query.
 */
async function showAccount(id) {
    let sql = `CALL show_account(?);`;
    let res;

    res = await db.query(sql, [id]);
    //console.log(res);
    console.info(`SQL: ${sql} got ${res.length} rows.`);

    return res[0];
}




/**
 * Create a new account.
 *
 * @async
 * @param {string} id      A id of the account.
 * @param {string} name    The name of the account holder.
 * @param {string} balance Initial amount in the account.
 *
 * @returns {void}
 */
async function createAccount(id, name, balance) {
    //Ropar på funktionen med parametrarna för inputen
    //dvs de som kommer med från det postade formuläret
    let sql = `CALL create_account(?, ?, ?);`;
    let res;

    res = await db.query(sql, [id, name, balance]);
    console.log(res);
    console.info(`SQL: ${sql} got ${res.length} rows.`);
}



/**
 * Delete an account.
 *
 * @async
 * @param {string} id The id of the account.
 *
 * @returns {void}
 */
async function deleteAccount(id) {
    let sql = `CALL delete_account(?);`;
    let res;

    res = await db.query(sql, [id]);
    //console.log(res);
    console.info(`SQL: ${sql} got ${res.length} rows.`);
}



/**
 * Edit details on an account.
 *
 * @async
 * @param {string} id      The id of the account to be updated.
 * @param {string} name    The updated name of the account holder.
 * @param {string} balance The updated amount in the account.
 *
 * @returns {void}
 */
async function editAccount(id, name, balance) {
    let sql = `CALL edit_account(?, ?, ?);`;
    let res;

    res = await db.query(sql, [id, name, balance]);
    //console.log(res);
    console.info(`SQL: ${sql} got ${res.length} rows.`);
}



/**
 * Show all entries in the account table.
 * Denna procedur tar inga argument, 
 * de hade vi annars kunnat bifoga via ?.
 * Visar balance för account-tabellen
 * igenom att använda CALL på proceduren show_balance
 * @async
 * @returns {RowDataPacket} Resultset from the query.
 */
/*async function showBalance() {
    let sql = `CALL show_category();`;
    let res;

    res = await db.query(sql);
    //console.log(res);
    console.info(`SQL: ${sql} got ${res.length} rows.`);

    //En lagrad procedur kan returnera flera resultset, 
    //i detta fall bara ett dock, det första och enda resultsetet från prodeduren
    return res[0];
}*/

async function viewLog(db, search) {
    let sql;
    let res;
    let str;
    let like = `%${search}%`;

    //limit number?
    console.info(`Searching for: ${search}`);

    sql = `
        SELECT
            produktkod,
            produktnamn,
            typ,
            hyllnummer
            antal
        FROM v_produktvy
        WHERE
            produktnamn LIKE ?
            OR produktkod = ?
            OR hyllnummer = ?
    `;
    res = await db.query(sql, [like, search, search,]);
    str = inventoryAsTable(res);
    return str;
}

async function viewShelves(db) {
    let sql;
    let res;
    let str;

  // sql = `CALL show_shelves();`;
    
    sql = `
        SELECT
            hyllnummer
        FROM lagerhylla;
    `;


   /* sql = `
        SELECT
            akronym,
            fornamn,
            efternamn,
            avdelning,
            lon
        FROM larare
        ORDER BY akronym;
    `;  */

    res = await db.query(sql);
    str = shelvesAsTable(res);
    return str;
}


async function viewInventory(db) {
    let sql;
    let res;
    let str;

  // sql = `CALL show_shelves();`;
    
/*    sql = `
        SELECT
            hyllnummer
        FROM lagerhylla;
    `;*/

    sql = `SELECT produktkod, produktnamn, typ, antal FROM v_produktvy;`

    res = await db.query(sql);
    str = inventoryAsTable(res);
    return str;
}


async function searchInventory(db, search) {
    let sql;
    let res;
    let str;
    let like = `%${search}%`;

    console.info(`Searching for: ${search}`);

    sql = `
        SELECT
            produktkod,
            produktnamn,
            typ,
            hyllnummer
            antal
        FROM v_produktvy
        WHERE
            produktnamn LIKE ?
            OR produktkod = ?
            OR hyllnummer = ?
    `;
    res = await db.query(sql, [like, search, search,]);
    str = inventoryAsTable(res);
    return str;
}


async function addToShelf(db, productid, shelf, number) {
    let sql;
    let res;
    let str;

  // sql = `CALL show_shelves();`;

  console.info(`Adding ${productid} to shelf ${shelf}, amount: ${number}`);


//Fråga Hadsan :D

    sql = `
        INSERT INTO v_produktvy (antal)
        VALUES (number)
        WHERE 
            produktid = ?
            && shelf = ?
    `;


   /* sql = `
        SELECT
            akronym,
            fornamn,
            efternamn,
            avdelning,
            lon
        FROM larare
        ORDER BY akronym;
    `;  */

    res = await db.query(sql);
    str = shelvesAsTable(res);
    return str;
}

function shelvesAsTable(res) {
    let str;

    //Got the error message "Line x exceeds the maximum line length of 100  max-len"
    //so I had to destroy the look of the following code for the tables to make it work
    str = "+------------+\n";
    str += "| Hyllnummer |\n";
    str += "|------------|\n";
    for (const row of res) {
       // let fodd = new Date(row.fodd).toISOString().slice(0, 10);

       // pad.End() behövs för att få tabellen rätt efter värdena :D


        str += "| ";
    /*    str += row.akronym.padEnd(10);
        str += "| ";
        str += (row.fornamn + " " + row.efternamn).padEnd(20);
        str += "| ";
        str += row.avdelning.padEnd(11);
        str += "| ";
        str += row.kon.padStart(6);
        str += " | ";
        str += row.lon.toString().padStart(8);
        str += " | ";
        str += row.kompetens.toString().padStart(5);
        str += " | ";
        str += fodd.padEnd(8);
        str += " | ";
        str += row.alder.toString().padStart(6);*/
        
       // str += row.hyllnummer.padStart(5);
        str += row.hyllnummer;
        str += " |\n";
    }
    str += "+------------+\n";

    return str;
}


function inventoryAsTable(res) {
    let str;

    //Got the error message "Line x exceeds the maximum line length of 100  max-len"
    //so I had to destroy the look of the following code for the tables to make it work
    str = "+------------+---------------+------------------------+--------+\n";
    str += "| Produktkod | Produktnamn   |  Kategori              | Antal  |\n";
    str += "+------------+---------------+------------------------+--------+\n";
    for (const row of res) {
    //    let fodd = new Date(row.fodd).toISOString().slice(0, 10);

        str += "| ";
        
/*       str += row.akronym.padEnd(10);
        str += "| ";
        str += (row.fornamn + " " + row.efternamn).padEnd(20);
        str += "| ";
        str += row.avdelning.padEnd(11);
        str += "| ";
        str += row.kon.padStart(6);
        str += " | ";
        str += row.lon.toString().padStart(8);
        str += " | ";
        str += row.kompetens.toString().padStart(5);
        str += " | ";
        str += fodd.padEnd(8);
        str += " | ";
        str += row.alder.toString().padStart(6);
*/
        str += row.produktkod.toString().padEnd(11);
        str += "| ";
        str += row.produktnamn.padEnd(13);
        str += " | ";
        str += row.typ.padEnd(22);
        str += " | ";
        str += row.antal.toString().padStart(6);
    //    str += row.typ.padStart(10);
       // str += "| ";
       // str += row.antal.toString().padStart(5);
        str += " |\n";
    }
    str += "+------------+---------------+------------------------+--------+\n";

    return str;
}

 /**
//  * Show all entries in the account table.
//  *
//  * @async
//  * @returns {RowDataPacket} Resultset from the query.
*/
async function showBalance() {
    return findAllInTable("kategori");
}



/**
//  * Show all entries in the selected table.
//  *
//  * @async
//  * @param {string} table A valid table name.
//  *
//  * @returns {RowDataPacket} Resultset from the query.
 */
async function findAllInTable(table) {
   let sql = `CALL show_category();`;
  // let sql =  `SELECT * FROM kategori;`
    let res;

    res = await db.query(sql, [table]);
    console.info(`SQL: ${sql} (${table}) got ${res.length} rows.`);

   return res;
}



/**
//  * Show all entries in the selected table.
//  *
//  * @async
//  * @param {string} table A valid table name.
//  *
//  * @returns {RowDataPacket} Resultset from the query.
 */
async function category(table) {
    let sql = `CALL show_history();`;
    // let sql =  `SELECT * FROM kategori;`
     let res;
 
     res = await db.query(sql, [table]);
     console.info(`SQL: ${sql} (${table}) got ${res.length} rows.`);
 
    return res[0];
}
 

async function showCategory() {
    return category("kategori");
}



async function product(table) {
    let sql = `CALL show_product();`;
   // let sql =  `SELECT * FROM kategori;`
     let res;

     res = await db.query(sql, [table]);
     console.info(`SQL: ${sql} (${table}) got ${res.length} rows.`);
 
    return res[0];
}
 
async function showProduct() {
    return product("v_produktvy");
}


async function createProduct(produktkod, produktnamn, beskrivning, kategori, pris) {
    //Ropar på funktionen med parametrarna för inputen
    //dvs de som kommer med från det postade formuläret
 //   let sql = `CALL create_product(?, ?, ?, ?, ?);`;
    let sql = `CALL create_product(?, ?, ?, ?, ?);`;
    let res;

    res = await db.query(sql, [produktkod, produktnamn, beskrivning, kategori, pris]);
    console.log(res);
    console.info(`SQL: ${sql} got ${res.length} rows.`);
}


async function productId(id) {
// ?? Ska det vara show_product 

    let sql = `CALL showId(?);`;
    let res;

    res = await db.query(sql, [id]);
    //console.log(res);
    console.info(`SQL: ${sql} got ${res.length} rows.`);

    return res[0];
}


async function editProduct(produktkod, produktnamn, pris) {
    let sql = `CALL edit_product(?, ?, ?);`;
    let res;

    res = await db.query(sql, [produktkod, produktnamn, pris]);
    //console.log(res);
    console.info(`SQL: ${sql} got ${res.length} rows.`);
}


async function deleteProduct(id) {
    let sql = `CALL delete_product(?);`;
    let res;

    res = await db.query(sql, [id]);
    //console.log(res);
    console.info(`SQL: ${sql} got ${res.length} rows.`);
}




/**
//  * Show all entries in the selected table.
//  *
//  * @async
//  * @param {string} table A valid table name.
//  *
//  * @returns {RowDataPacket} Resultset from the query.
 */
//async function findAllInTable(table) {
 //   let sql = `SELECT * FROM ??;`;
//    let res;

//    res = await db.query(sql, [table]);
  //  console.info(`SQL: ${sql} (${table}) got ${res.length} rows.`);

 //  return res;
//}
