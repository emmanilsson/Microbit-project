-- Skapa tabellerna för eshopen CdOff
-- Emma Nilsson
--

USE eshop;


-- PRIMARY KEY används för att ha unika värden
-- PRIMARY KEY används för att samla ihop exakt likadana värden från olika tabeller

DROP TABLE IF EXISTS orderrad;
DROP TABLE IF EXISTS fakturarad;
DROP TABLE IF EXISTS plocklista;
DROP TABLE IF EXISTS faktura;
DROP TABLE IF EXISTS lagerhylla;
DROP TABLE IF EXISTS lager;
DROP TABLE IF EXISTS kategori;
DROP TABLE IF EXISTS produkt2kategori;
DROP TABLE IF EXISTS produkt;
DROP TABLE IF EXISTS kundorder;
DROP TABLE IF EXISTS kund;

CREATE TABLE kund
(
	id INT,
    fornamn VARCHAR(100),
    efternamn VARCHAR(100),
    adress VARCHAR(100),
    land VARCHAR(20),
    telefonnummer INT,
    
    PRIMARY KEY (id)
);


CREATE TABLE kundorder
(
	ordernummer INT AUTO_INCREMENT NOT NULL,
    kundID INT, 
    fornamn VARCHAR(100),
    efternamn VARCHAR(100),
    adress VARCHAR(100),
    land VARCHAR(20),
    telefonnummer INT,
    
    antal INT,
    produkt VARCHAR(100) UNIQUE,
    
    PRIMARY KEY (ordernummer, produkt),
    FOREIGN KEY (kundID) REFERENCES kund(id)
);


CREATE TABLE produkt
(
	produktkod INT,
    produktnamn VARCHAR(100),
    beskrivning VARCHAR(100),
    kategori VARCHAR(100),
    pris INT,
    
    PRIMARY KEY (produktkod)
   -- FOREIGN KEY (produktnamn) REFERENCES kundorder(produkt)
);


CREATE TABLE faktura
(
	faktura_nmr INT AUTO_INCREMENT NOT NULL,
    namn VARCHAR(100),
    produkt CHAR(20),
    pris INT,
    antal INT,
    summa INT,
    
    PRIMARY KEY (faktura_nmr),
    FOREIGN KEY (faktura_nmr) REFERENCES kundorder(ordernummer)
);



CREATE TABLE lager
(
	produkt_namn VARCHAR(100),
    antal INT, 
    lagerhylla INT UNIQUE,
    
    PRIMARY KEY (produkt_namn)
  --  FOREIGN KEY (produkt_namn) REFERENCES produkt(produktnamn)
);



CREATE TABLE lagerhylla
(
	produkt_namn VARCHAR(100),
    antal INT,
	hyllnummer INT,
    
    PRIMARY KEY (hyllnummer)
    -- FOREIGN KEY (produkt_namn) REFERENCES produkt(produktnamn),
	-- FOREIGN KEY (hyllnummer) REFERENCES lager(lagerhylla)
    -- FOREIGN KEY (hyllnummer) REFERENCES lager(hylla)
);

CREATE TABLE plocklista
(
	order_nmr INT AUTO_INCREMENT NOT NULL,
    namn VARCHAR(100),
    adress VARCHAR(100),
    antal INT,
    produkt CHAR(20),
    hylla INT,
    
    PRIMARY KEY (order_nmr),
    FOREIGN KEY (order_nmr) REFERENCES kundorder(ordernummer)
    -- FOREIGN KEY (hylla) REFERENCES lagerhylla(hyllnummer)
);


CREATE TABLE produkt2kategori
(
	produktid INT,
    produktnamn VARCHAR(100),
    typ VARCHAR(100)
	
   -- PRIMARY KEY (typ)
   -- FOREIGN KEY (typ) REFERENCES produkt(kategori)
);

CREATE TABLE kategori
(
	typ VARCHAR(100),
	
    PRIMARY KEY (typ)
    -- FOREIGN KEY (typ) REFERENCES produkt(kategori)
);


CREATE TABLE orderrad
(
	id INT,
    produkt VARCHAR(100),
    pris INT,
    
    PRIMARY KEY (id)
  --  FOREIGN KEY (id) REFERENCES kundorder(ordernummer),
 --   FOREIGN KEY (produkt) REFERENCES produkt(produktnamn)
);


CREATE TABLE fakturarad
(
	id INT AUTO_INCREMENT,
    produkt INT,
    antal INT,
    
    PRIMARY KEY (id),
    FOREIGN KEY (id) REFERENCES faktura(faktura_nmr)
);

--
-- Create procedure for select * from kategori
--
DROP PROCEDURE IF EXISTS show_category;
DELIMITER ;;
CREATE PROCEDURE show_category()
BEGIN
    SELECT * FROM kategori;
END
;;
DELIMITER ;







DROP PROCEDURE IF EXISTS show_product;
DELIMITER ;;
CREATE PROCEDURE show_product()
BEGIN
   
   DROP VIEW IF EXISTS v_produkt;
CREATE VIEW v_produkt
AS
SELECT DISTINCT
    p.idprodukt AS produktnamn,
    l.antal as antal,
    p.typ as kat
FROM produkt2kategori AS p
    RIGHT JOIN lagerhylla AS l
        ON p.produktid = l.produkt_namn
;

SELECT * FROM v_produkt;



DROP VIEW IF EXISTS v_typ;
CREATE VIEW v_typ
AS
SELECT DISTINCT
	p.produktnamn AS produktnamn,
    p.antal as antal,
    GROUP_CONCAT(p.kat),
	k.typ
FROM v_produkt AS p
    LEFT JOIN kategori AS k
        ON p.kat = k.typ
;

SELECT * FROM v_typ;








DROP VIEW IF EXISTS v_produktvy;
CREATE VIEW v_produktvy
AS
SELECT DISTINCT 
	p.produktkod,
	t.produktnamn AS produktnamn,
    p.kategori,
    GROUP_CONCAT(t.typ),
    p.antal as antal,
    p.pris
FROM v_typ AS t
    LEFT OUTER JOIN produkt AS p
        ON t.typ = p.kategori
;

SELECT * FROM v_produktvy;
END
;;
DELIMITER ;
