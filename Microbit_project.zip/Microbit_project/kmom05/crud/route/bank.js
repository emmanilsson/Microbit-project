/**
 * Route for bank.
 */
"use strict";

const express    = require("express");
const router     = express.Router();


//Body Parser aktiveras bara i den fil vi använder den,
//alltså i samma fil som vår post-route ligger
const bodyParser = require("body-parser");

//Middleware som kan läggas till i vår route 
//för att parsa innehåller i postade formulär
const urlencodedParser = bodyParser.urlencoded({ extended: false });
const bank       = require("../src/bank.js");
const sitename   = "| The Bank";

module.exports = router;

router.get("/index", (req, res) => {
    let data = {
        title: `Welcome ${sitename}`
    };

    res.render("bank/index", data);
});

router.get("/balance", async (req, res) => {
    let data = {
        title: `Account balance ${sitename}`
    };

    data.res = await bank.showBalance();

    res.render("bank/balance", data);
});

router.get("/create", (req, res) => {
    let data = {
        title: `Create new account ${sitename}`
    };

    res.render("bank/create", data);
});

router.post("/create", urlencodedParser, async (req, res) => {
    //Extract the data from the posted form
    //console.log(JSON.stringify(req.body, null, 4));
    
    //Send data to a stored procedure
    //I routens callback har vi nu det postade formuläret, re.body.x)
    await bank.createAccount(req.body.id, req.body.name, req.body.balance);
    
    //Vi redirectas/skickas vidare till routen /bank/balance som renderar ett svar
    res.redirect("/bank/balance");

    //Nu måste vi extrahera datat som kommer i det postade formnuläret
    //Vi använder modulen body-parser
    //Den extraherar den kodade infon i HTTP-requesten
});

//Dynamisk route som tar en parameter så routen blev bank/acoount/:id
//där :id representerar kontots id 
//Exempelvis: bank/account/2222 ger Evas konto
router.get("/account/:id", async (req, res) => {
    //hur representationen av :id kan hämtas i datan om requesten via req.params.id
    //Som att skicka en parameter via länken

    let id = req.params.id;
    let data = {
        title: `Account ${id} ${sitename}`,
        account: id
    };

    //Anropar en lagrad procedur som hämtar detaljer
    //om just ett konto id, som bifogas som ett argument till funktionen
    data.res = await bank.showAccount(id);

    res.render("bank/account-view", data);
});

//samma som acconut/id enda skillnaden är vy och title
router.get("/edit/:id", async (req, res) => {
    let id = req.params.id;
    let data = {
        title: `Edit account ${id} ${sitename}`,
        account: id
    };

    data.res = await bank.showAccount(id);

    res.render("bank/account-edit", data);
});

router.post("/edit", urlencodedParser, async (req, res) => {
    //console.log(JSON.stringify(req.body, null, 4));
    await bank.editAccount(req.body.id, req.body.name, req.body.balance);
    res.redirect(`/bank/edit/${req.body.id}`);
});

router.get("/delete/:id", async (req, res) => {
    let id = req.params.id;
    let data = {
        title: `Delete account ${id} ${sitename}`,
        account: id
    };

    data.res = await bank.showAccount(id);

    res.render("bank/account-delete", data);
});

router.post("/delete", urlencodedParser, async (req, res) => {
    //console.log(JSON.stringify(req.body, null, 4));
    await bank.deleteAccount(req.body.id);
    res.redirect(`/bank/balance`);
});
