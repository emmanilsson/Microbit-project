/**
 * A module exporting functions to access the bank database.
 */
"use strict";

module.exports = {
    toAdam: toAdam,
    toEva: toEva
};

//På modulnivå, tillgängliga i alla funktioner
const mysql  = require("promise-mysql");
const config = require("../config/db/bank.json");
let db;

/**
 * Main function.
 * @async
 * @returns void
 */
(async function() {
    db = await mysql.createConnection(config);

    //Eventhanterare som kopplar ner databasen när programmet avslutas
    process.on("exit", () => {
        db.end();
    });
})();

/**
 * Show all entries in the account table.
 *
 * @async
 * @returns {RowDataPacket} Resultset from the query.
 */
async function toAdam() {
    return moneyToAdam("account");
}

async function toEva() {
    return moneyToEva("account");
}

/**
 * Move money to Eva or Adam using a multiquery
 *
 */
async function moneyToEva() {
    let str;

    console.info(`(Move 1.5 money from 1111 to 2222.)`);

    console.info(`Eva got 1.5 pengar, she is currently checking out her account balance.`);


    db.query("START TRANSACTION;", function (error) {
        if (error) {
            throw error;
        }
        // `results` is an array with one element for every statement in the query:
    });

    let sql = "UPDATE account SET balance = balance + 1.5 WHERE id = '2222';";

    db.query(sql, function (error) {
        if (error) {
            throw error;
        }
    });

    let que = "UPDATE account SET balance = balance - 1.5 WHERE id = '1111';";

    db.query(que, function (error) {
        if (error) {
            throw error;
        }
    });

    db.query("COMMIT;", function (error) {
        if (error) {
            throw error;
        }
    });

    db.query("SELECT * FROM account;", function (error) {
        if (error) {
            throw error;
        }
        // `results` is an array with one element for every statement in the query:
        //console.log(results[0]); // [{1: 1}]
        //console.log(results[1]); // [{2: 2}]
    });


    return str;
}
async function moneyToAdam() {
    let str;

    console.info(`(Move 1.5 money from 2222 to 1111.)`);

    console.info(`Adam got 1.5 pengar, he is currently checking out his account balance.`);


    db.query("START TRANSACTION;", function (error) {
        if (error) {
            throw error;
        }
        // `results` is an array with one element for every statement in the query:
    });

    let sql = "UPDATE account SET balance = balance + 1.5 WHERE id = '1111';";

    db.query(sql, function (error) {
        if (error) {
            throw error;
        }
        // `results` is an array with one element for every statement in the query:
    });


    let que = "UPDATE account SET balance = balance - 1.5 WHERE id = '2222';";

    db.query(que, function (error) {
        if (error) {
            throw error;
        }
        // `results` is an array with one element for every statement in the query:
    });

    db.query("COMMIT;", function (error) {
        if (error) {
            throw error;
        }
        // `results` is an array with one element for every statement in the query:
    });

    db.query("SELECT * FROM account;", function (error) {
        if (error) {
            throw error;
        }
    });

    return str;
}
